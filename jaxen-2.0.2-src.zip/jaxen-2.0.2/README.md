# jaxen

[![Maven Central](https://img.shields.io/maven-central/v/jaxen/jaxen.svg?label=Maven%20Central)](https://search.maven.org/search?q=g:%22jaxen%22%20AND%20a:%22jaxen%22)

The Jaxen XPath Engine for Java

Jaxen is an open source XPath 1.0 library written in Java.
It is adaptable to many different object models, including
DOM, XOM, dom4j, and JDOM. It is also possible to write
adapters that treat non-XML trees such as compiled Java byte code
or Java beans as XML, thus enabling you to query these trees with XPath too.

The current version is *2.0.2*. This release requires Java 1.5 or later.
If you're still using Java 1.4 or earlier, try Jaxen 1.2.0. 
If you're still using Java 1.3 or earlier, try Jaxen 1.1.6. 

## Adding Jaxen to your build

Jaxen's Maven group ID is `jaxen` and its artifact ID is `jaxen`. To add a dependency on jaxen using Maven, add this `dependency` element to your pom.xml:

```xml
<dependency>
  <groupId>jaxen</groupId>
  <artifactId>jaxen</artifactId>
  <version>2.0.2</version>
</dependency>
```

To add a dependency using Gradle:

```gradle
dependencies {
  compile 'jaxen:jaxen:2.0.2'
}
```

## Building from Source

To build Jaxen from source, you need Java 8+ and Maven 3.6.3+. The project includes a Maven wrapper for convenience:

```bash
# Using Maven wrapper (recommended)
./mvnw clean test

# Or using system Maven if installed
mvn clean test
```

## Reproducible Builds

Jaxen supports [Maven reproducible builds](https://maven.apache.org/guides/mini/guide-reproducible-builds.html).
This means that building the same source code multiple times will produce bit-for-bit identical artifacts,
enabling better security and verification of releases.

To verify that builds are reproducible, you can run the included verification script:

```bash
./verify-reproducible-build.sh
```

The reproducible build timestamp is configured in the `project.build.outputTimestamp` property in the main `pom.xml`.


## Development and API Compatibility

Jaxen includes comprehensive automated API compatibility checking:

1. **Java API Compatibility**: Uses Animal Sniffer to ensure code only uses APIs available in Java 1.5
2. **Jaxen API Protection**: Uses Japicmp to detect breaking changes to jaxen's own public API

This dual approach helps maintain backward compatibility and prevents accidental introduction of breaking changes.

See [API_COMPATIBILITY.md](API_COMPATIBILITY.md) for detailed information about the API compatibility checking system.
