# Security Policy

## Reporting Security Issues

If it's a real issue you've personally discovered and can explain, feel free to drop me an email.

If it's some security tool logging a warning, that is 95% likely not to be a security issue but rather a bug in the tool. You can file that here after you have investigated if you are willing to vouch that it is a true security issue, but be aware that these tools are almost never correct when analyzing Jaxen.

## What is **NOT** a Security Bug in Jaxen

1. Anything in your dependency tree whose source code is not in this repo. You control your classpath. Jaxen doesn't. If you don't like what's in the classpath, change it.
2. Properly implementing XML 1.0 according to the specification.
3. Properly implementing XPath 1.0 according to the specification.
4. Being able to load a URL from Java code.

## Probably Not Security Bugs in Jaxen

* Problems that only appear when your code (not Jaxen's) accepts untrusted, unvalidated user input

## Possible Security Bugs in Jaxen

If you can find one, none are currently known to exist:

* XPath expressions that cause infinite loops in the parser or exponential performance problems.
* XPath expressions that throw unexpected runtime exceptions. E.g. if you're passing null directly to a method via an API call,  an exception is expected. However, if you're querying a non-null document with a non-null XPath expression and you get a `NullPointerException` or `IndexOutOfBoundsException`, that is at least a bug, and maybe a security issue.
* A very large document, possibly one constructed using internal entity references, might perhaps trigger some "interesting" behavior. Since Jaxen sits on top of Java it has some size limitations XML does not. For example, XML lists and arrays tend to have a maximum size of about 2.1 billion elements while there's no such limit on an XML document. Whether this is exploitable in any meaningful way is unknown. If this is a concern, configure the XML parser to reject exceissively large documents before passing them to Jaxen.
