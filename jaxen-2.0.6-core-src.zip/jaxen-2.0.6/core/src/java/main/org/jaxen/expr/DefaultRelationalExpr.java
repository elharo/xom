/*
 * Copyright 2000-2002 bob mcwhirter & James Strachan.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 * 
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 * 
 *   * Neither the name of the Jaxen Project nor the names of its
 *     contributors may be used to endorse or promote products derived 
 *     from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ====================================================================
 * This software consists of voluntary contributions made by many 
 * individuals on behalf of the Jaxen Project and was originally 
 * created by bob mcwhirter <bob@werken.com> and 
 * James Strachan <jstrachan@apache.org>.  For more information on the 
 * Jaxen Project, please see <https://github.com/jaxen-xpath/jaxen/>.
 */



package org.jaxen.expr;

import java.util.Iterator;
import java.util.List;
import org.jaxen.Context;
import org.jaxen.JaxenException;
import org.jaxen.Navigator;
import org.jaxen.function.NumberFunction;

abstract class DefaultRelationalExpr extends DefaultTruthExpr implements RelationalExpr 
  {
  DefaultRelationalExpr( Expr lhs, Expr rhs )
    {
    super( lhs, rhs );
    }
  
  Object evaluateChain( List<Object> values, Context context ) throws JaxenException
    {
    Navigator nav = context.getNavigator();
    Object lhsValue = values.get(values.size() - 1);
    for (int i = values.size() - 2; i >= 0; i--)
    {
      lhsValue = evaluateComparison( lhsValue, values.get(i), nav );
    }
    return lhsValue;
    }

  private Object evaluateSetSet( List lhsSet, List rhsSet, Navigator nav )
    {
    if( setIsEmpty( lhsSet ) || setIsEmpty( rhsSet ) ) // return false if either is null or empty
      {
      return Boolean.FALSE;
      }    
    
    for( Iterator lhsIterator = lhsSet.iterator(); lhsIterator.hasNext(); )
      {
      Object lhs = lhsIterator.next();        
      
      for( Iterator rhsIterator = rhsSet.iterator(); rhsIterator.hasNext(); )
        {
        Object rhs = rhsIterator.next();
        
        if( evaluateObjectObject( lhs, rhs, nav ) )
          {
          return Boolean.TRUE;
          }
        }
      }      
    
    return Boolean.FALSE;
    }
  
  private boolean evaluateObjectObject( Object lhs, Object rhs, Navigator nav )
    {
    if( lhs == null || rhs == null )
      {
      return false;
      }
    
    Double lhsNum = NumberFunction.evaluate( lhs, nav );
    Double rhsNum = NumberFunction.evaluate( rhs, nav );      
    
    if( NumberFunction.isNaN( lhsNum ) || NumberFunction.isNaN( rhsNum ) )
      {
      return false;
      }
    
    return evaluateDoubleDouble( lhsNum, rhsNum );
    }
  
  private Boolean evaluateComparison( Object lhsValue, Object rhsValue, Navigator nav )
    {
    if( bothAreSets( lhsValue, rhsValue ) )
      {
      return (Boolean) evaluateSetSet( (List) lhsValue, (List) rhsValue, nav );
      }
    
    if (isBoolean(rhsValue) && isSet(lhsValue)) {
        List left = convertToList( lhsValue );
        if (left.isEmpty()) {
            return evaluateObjectObject(rhsValue, Boolean.FALSE, nav) ? Boolean.TRUE : Boolean.FALSE;
        }
        else {
            return evaluateObjectObject(rhsValue, Boolean.TRUE, nav) ? Boolean.TRUE : Boolean.FALSE;
        }
    }
    else if (isBoolean(lhsValue) && isSet(rhsValue)) {
        List right = convertToList( rhsValue );
        if (right.isEmpty()) {
            return evaluateObjectObject(lhsValue, Boolean.FALSE, nav) ? Boolean.TRUE : Boolean.FALSE;
        }
        else {
            return evaluateObjectObject(lhsValue, Boolean.TRUE, nav) ? Boolean.TRUE : Boolean.FALSE;
        }
    }
    
    if( eitherIsSet( lhsValue, rhsValue ) )
      {
      if( isSet( lhsValue ) )
        {        
        return (Boolean) evaluateSetSet( (List) lhsValue, convertToList( rhsValue ), nav );              
        }
      else
        {
        return (Boolean) evaluateSetSet( convertToList( lhsValue ), (List) rhsValue, nav );              
        }
      }
    
    return evaluateObjectObject( lhsValue, rhsValue, nav ) ? Boolean.TRUE : Boolean.FALSE;
    }
  
  protected abstract boolean evaluateDoubleDouble( Double lhs, Double rhs );    
  }
